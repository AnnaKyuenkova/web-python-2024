def show_employee(name, salary=100000):
    return f"{name}: {salary} ₽"