import sys

def my_sum_argv(num):
    return sum([int(i) for i in num])